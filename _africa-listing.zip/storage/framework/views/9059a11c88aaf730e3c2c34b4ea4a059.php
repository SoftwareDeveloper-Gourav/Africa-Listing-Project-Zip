<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section>
    <div class="tp">
        <ul itemscope itemtype="https://schema.org/BreadcrumbList">
            <li itemprop="itemListElement" ><a href="javascript:void(0)"
                    itemprop="item"><span itemprop="name">Africa</span></a>
                <meta itemprop="position" content="1" />
            </li>
            <li>Browse Categories</li>
        </ul>
    </div>
    <h1>List of All Categories in Africa Listing.</h1>
    <div id="page_text">This is a list of Categories in Africa Listing .</div>
  
    <div class="box">
       <?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul class="cat_list" >
            <li style="color: #414141;
    border: solid 1px #eee;
    line-height: 36px;
    height: 36px;
    display: block;
    margin: 0 5px;
    padding: 0 45px 0 15px;
    border-radius: 2px;
    background: #f6f7f9;
    position: relative;
    font-size: 14px;
    margin-top:10px;"><a href="<?php echo e(url('category/listing')); ?>/<?php echo e($category_data->id); ?>" title="Companies in Ras Al Khaimah" class="city238"><?php echo e($category_data->category_name); ?></a></li>
        </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        

        <div class="clear"></div>
    </div>
</section><br> <br> <br> <br>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\LARAVEL_PROJECTS\now-working\resources\views/all_category.blade.php ENDPATH**/ ?>