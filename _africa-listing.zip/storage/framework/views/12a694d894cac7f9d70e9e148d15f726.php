<?php echo $__env->make('admin.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-wrapper">

<div class="card">
              <div class="card-header">
                <h2 class="card-title">Listing Table</h2>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table class="table table-bordered table-striped" id="table">
                  <thead>
                  <tr>
                    <th>Sl. No</th>
                    <th>Listing</th>
                    <th>Category</th>
                    <th>Address</th>
                    <th>Status</th>
                    <th colspan="2" class="text-center">Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                        $no = 1;
                    ?>
                 <?php if(count($listing_data)>0): ?>
                 <?php $__currentLoopData = $listing_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr id="<?php echo e($val->listing_id); ?>">
                     <td><?php echo e($no++); ?></td>
                     <td><?php echo e($val->listing_title); ?></td>
                     <td><?php echo e($val->category_name); ?></td>
                     <td><?php echo e($val->address); ?></td>
                     <td>
           <select name="" class="form-control" id="" onchange="ListingStatus(this.value,<?php echo e($val->listing_id); ?>)">
 <option value="1" <?php if($val->status==1): ?> selected   
           <?php endif; ?>>Active</option>
           <option value="0" <?php if($val->status==0): ?> selected       
             <?php endif; ?>>Deactive</option>
           </select>
                     </td>
                     <td class="text-center">
                         <a href="<?php echo e(route('admin.dashboard.listing-update',['id'=>$val->listing_id])); ?>" class="btn btn-primary">Update &nbsp;<i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                         </a> &ensp;
                         <a href="javascript:void(0)" onclick="DeleteListing(<?php echo e($val->listing_id); ?>)" class="btn btn-danger">Delete &nbsp; <i class="fa fa-trash" aria-hidden="true"></i></a>

                     </td>

                 </tr>

                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                 <?php else: ?> 
                 <td colspan="6" style="color:red; text-align:center; ">Listing Not Found</td>
                 <?php endif; ?>


                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
</div>
<?php echo $__env->make('admin.dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
<?php /**PATH C:\xampp\htdocs\LARAVEL-PROJECT\multiple-listing\resources\views/admin/dashboard/view-listing.blade.php ENDPATH**/ ?>