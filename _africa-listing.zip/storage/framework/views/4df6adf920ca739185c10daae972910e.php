<?php echo $__env->make('admin.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
  svg{
    display: none;
  }
  .leading-5{
    margin-top:16px !important;
  }
  .justify-between{
   margin-top:20px !important;
  }
  .text-small{
    white-space: nowrap; 
  width: 170px; 
  overflow: hidden;
  text-overflow: ellipsis; 
  }
  </style>
<div class="content-wrapper">

<div class="card">
              <div class="card-header">
                <h2 class="card-title">Listing Table</h2>
              </div>
              <!-- /.card-header -->
              <div class="card-body" style="overflow: scroll">
                <form action="<?php echo e(url('admin/dashboard/search')); ?>">
                <div class="row">
                    <div class="col-md-2">
                    <select name="country" id="" class="form-control" required>
                    <option value="">Select Country</option>
                     <?php $__currentLoopData = $all_country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($country->country); ?>"><?php echo e($country->country); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  </div>
                   <div class="col-md-2">
                    <select name="category" id="" class="form-control" required>
                    <option value="">Select Category</option>
                    <?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  </div>
                   <div class="col-md-2">
                    <button type="submit" class="btn btn-primary">Filter</button>
                </div>
                </div> <br>

              </form>
             
                <table class="table table-bordered table-striped" id="table">
                  <thead>
                  <tr>
                    <th>Sl. No</th>
                    <th>Listing Logo</th>
                    <th>Listing</th>
                    <th>Category</th>
                    <th>Address</th>
                    <th>Status</th>
                    <th colspan="2" class="text-center">Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                        $no = 1;
                    ?>
                 <?php if(count($listing_data)>0): ?>
                 <?php $__currentLoopData = $listing_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr id="<?php echo e($val->listing_id); ?>">
                     <td><?php echo e($no++); ?></td>
                      <td><img src="<?php echo e(url('listing_photo')); ?>/<?php echo e($val->photo); ?>" alt="" class="img-thumbnail" style="width:50px;"></td>
                     <td ><p class="text-small"><?php echo e($val->listing_title); ?></p></td>
                     <td><?php echo e($val->category_name); ?></td>
                     <td><?php echo e($val->address); ?></td>
                     <td>
           <select name="" class="form-control" id="" onchange="ListingStatus(this.value,<?php echo e($val->listing_id); ?>)">
 <option value="1" <?php if($val->status==1): ?> selected   
           <?php endif; ?>>Active</option>
           <option value="0" <?php if($val->status==0): ?> selected       
             <?php endif; ?>>Deactive</option>
           </select>
                     </td>
                     <td class="text-center">
                         <a href="<?php echo e(route('admin.dashboard.listing-update',['id'=>$val->listing_id])); ?>" class="btn btn-primary"> <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                         </a> &ensp;
                         <a href="javascript:void(0)" onclick="DeleteListing(<?php echo e($val->listing_id); ?>)" class="btn btn-danger"> <i class="fa fa-trash" aria-hidden="true"></i></a>

                     </td>

                 </tr>

                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                 <?php else: ?> 
                 <td colspan="6" style="color:red; text-align:center; ">Listing Not Found</td>
                 <?php endif; ?>


                  </tbody>
                </table>
                <div class="">
                  <?php echo e($listing_data->links()); ?>

                </div>
              </div>
              <!-- /.card-body -->
            </div>
</div>
<?php echo $__env->make('admin.dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
<script>
  $('#listing').addClass('active');
  $('#view-listing').addClass('active');
</script><?php /**PATH C:\xampp\htdocs\LARAVEL_PROJECTS\africa-listing\resources\views/admin/dashboard/view-listing.blade.php ENDPATH**/ ?>