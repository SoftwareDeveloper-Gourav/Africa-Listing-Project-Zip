<?php echo $__env->make('user.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Dashboard </li>
            </ol>
          </div> <!-- /.col -->
        </div> <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
         <div class="col md-12 col-lg-12 m-auto">
          <center>
            <img src="<?php echo e(url('img/africa-logo.png')); ?>" alt="" style="width:105px;">
          </center>
          <h3 class="text-success text-center"> <b>Congratulation !</b></h3>
         </div>
         <div class="col md-12 col-lg-312 m-auto">
          <h3 class="text-center"> <b>You have successfully joined Africa Listing Site</b></h3>
          <br>
          <p class="text-center" style="font-size:21px;">Please Submit Your Company Listing </p>
          <div class="text-center">
            <img src="<?php echo e(url('star.png')); ?>" alt="" style="width:35px;">   
            <img src="<?php echo e(url('star.png')); ?>" alt="" style="width:35px;">   
            <img src="<?php echo e(url('star.png')); ?>" alt="" style="width:35px;">   
            <img src="<?php echo e(url('star.png')); ?>" alt="" style="width:35px;">   
            <img src="<?php echo e(url('star.png')); ?>" alt="" style="width:35px;">  
             
          </div>
         
         </div>     
        </div>
       
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php echo $__env->make('user.dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\LARAVEL-PROJECT\multiple-listing\resources\views/user/dashboard/index.blade.php ENDPATH**/ ?>