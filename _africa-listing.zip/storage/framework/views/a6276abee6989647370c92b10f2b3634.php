<?php echo $__env->make('user.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h5>Update Listing Form</h5>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Listing Update Form</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-md-12">
                    <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Update Listing Form</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <form id="user_update_listing_form">
                            <div class="card-body">

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Select Category</label>
                                    <select name="category_id" id="category" class="form-control"
                                        onchange="Name(this.value)">
                                        <option value="">Select Category</option>
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($value->id); ?>" <?php if($listing_data->cat_id==$value->id): ?> selected <?php endif; ?> ><?php echo e($value->category_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <label for="exampleInputEmail1" id="name_change">Listing Name / Title</label>
                                    <input type="text" id="name_placeholder" class="form-control"
                                        id="exampleInputEmail1" placeholder="Enter Company Name" name="company" required value="<?php echo e($listing_data->listing_title); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Address</label>
                                    <input type="text" name="address" class="form-control"
                                    id="location" placeholder="Enter Address Here" >
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Country</label>
                                    <input type="text" name="country" class="form-control"
                                    id="country" placeholder="Enter Country Name" value="<?php echo e($listing_data->country); ?>">
                                </div>
                                <input type="hidden" name="lat" id="lat" class="form-control" required>
                                <input type="hidden" name="listing_id" value="<?php echo e($listing_data->listing_id); ?>">
                                <input type="hidden" name="lng" id="lng" class="form-control">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Phone Number</label>
                                    <input type="number" name="phone_number" class="form-control"
                                        id="exampleInputEmail1" placeholder="Enter Phone No Here" required  value="<?php echo e($listing_data->phone_number); ?>" >
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Mobile Number</label>
                                    <input type="number" name="mobile_number" class="form-control"
                                        placeholder="Enter Mobile No Here" required  value="<?php echo e($listing_data->mobile_number); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">FAX</label>
                                    <input type="number" id="" class="form-control"
                                         id="exampleInputEmail1" placeholder="FAX" name="fax" value="<?php echo e($listing_data->fax); ?>" >
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email</label>
                                    <input type="email" class="form-control"
                                        id="exampleInputEmail1" placeholder="Type Email Here" name="email" required  value="<?php echo e($listing_data->email); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Website</label>
                                    <input type="url" class="form-control"
                                        id="exampleInputEmail1" placeholder="Type Website Here" name="website"  value="<?php echo e($listing_data->website); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Description</label>
                                     <textarea name="desc" class="form-control" id="" cols="30" rows="5" placeholder="Type Listing Description Here"><?php echo e($listing_data->description); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Establishment Year</label>
                                    <input type="number" id="" class="form-control"
                                    id="exampleInputEmail1" placeholder="Enter Establishment Year" name="year" value="<?php echo e($listing_data->year); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Employes</label>
                                    <input type="number" id="" class="form-control"
                                    id="exampleInputEmail1" placeholder="Enter Total Employes Number Here" name="employe" value="<?php echo e($listing_data->employe); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Manager Name</label>
                                    <input type="text" id="" class="form-control"
                                        id="exampleInputEmail1" placeholder="Enter Manager Name Here" name="manager" value="<?php echo e($listing_data->manager); ?>">
                                </div>


                                
                                <div class="form-group">
                                    <div class="form-group">

                                        <label for="">Select Listing Image</label>
                                        <input type="file" name="file" class="form-control" id="imageInput"
                                            onchange="previewImage()">
                                    </div>
                                    <img id="imagePreview" src="#" alt=""
                                        style="width:200px; border-radius:5px;" />
                                        <label for="" style="margin-left:10px;">If you don't change the photo, the previous photo will remain ..</label>

                                </div>

                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                <center>
                                    <button type="submit" class="btn btn-primary" id="btn">Update Listing 
                                        &nbsp;
                                         </button>

                                </center>
                                <br>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->





                </div>
                <!--/.col (left) -->
                <!-- right column -->

                <!--/.col (right) -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<script>
    function previewImage() {
        var preview = document.querySelector('#imagePreview');
        var file = document.querySelector('#imageInput').files[0];
        var reader = new FileReader();

        reader.addEventListener("load", function() {
            preview.src = reader.result;
        }, false);

        if (file) {
            reader.readAsDataURL(file);
        }
    }
</script>

<?php echo $__env->make('user.dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    $(document).ready(function(){
      var autocomplete;
      var id ="location";
      autocomplete = new google.maps.places.Autocomplete((document.getElementById(id)),{
         types:['geocode'],
      })
      google.maps.event.addListener(autocomplete,'place_changed',function(){
        var place = autocomplete.getPlace();
       
           $('#lat').val(place.geometry.location.lat());
           $('#lng').val(place.geometry.location.lng());
        
        
    })
    });
  </script>
  <script>
    $(document).ready(function(){
      var autocomplete;
      var id ="country";
      autocomplete = new google.maps.places.Autocomplete((document.getElementById(id)),{
         types:['geocode'],
      })
      google.maps.event.addListener(autocomplete,'place_changed',function(){
        var place = autocomplete.getPlace();
    
        
        
    })
    });
  </script>
<?php /**PATH C:\xampp\htdocs\LARAVEL-PROJECT\africa\resources\views/user/dashboard/edit-listing.blade.php ENDPATH**/ ?>