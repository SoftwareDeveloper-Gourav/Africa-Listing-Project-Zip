<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section>
    <div class="tp">
        <ul itemscope itemtype="https://schema.org/BreadcrumbList">
            <li itemprop="itemListElement" ><a href="javascript:void(0)"
                    itemprop="item"><span itemprop="name">Africa</span></a>
                <meta itemprop="position" content="1" />
            </li>
            <li>Browse Categories</li>
        </ul>
    </div>
    <h1>List of All Categories in Africa Listing.</h1>
    <div id="page_text">This is a list of Categories in Africa Listing .</div>
  
    <div class="box">
       <?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul class="cat_list" >
            <li style="margin-top:10px;"><a href="<?php echo e(url('category/listing')); ?>/<?php echo e($category_data->id); ?>" title="Companies in Ras Al Khaimah" class="city238"><?php echo e($category_data->category_name); ?></a></li>
        </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        

        <div class="clear"></div>
    </div>
</section><br> <br> <br> <br>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/u729855735/domains/kyptronixllp.co.in/public_html/africa-listing/resources/views/all_category.blade.php ENDPATH**/ ?>