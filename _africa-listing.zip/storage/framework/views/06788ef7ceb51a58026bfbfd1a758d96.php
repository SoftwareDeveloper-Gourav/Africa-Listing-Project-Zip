<footer style="background-color: #1c1720;">
    <section>
        <div class="footer_box">
            <h6>Links</h6>
            <ul>
                <li><a href="#">Browse
                        Categories</a></li>
                <li><a href="#">Browse
                        Locations</a></li>
                <li><a href="#l">Jobs in Africa Today</a></li>
                <li><a
                        href="#">Our
                        Global Network</a></li>
                <li><a href="#">Public Holidays in
                        Africa</a></li>
                </ul>
        </div>
        <div class="footer_box">
            <h6>Users</h6>
            <ul>
                <li><a href="#">Add Business</a></li><li><a
                        href="#"
                        rel="nofollow">Remove Company</a></li><li><a
                        href="#">Sign in</a></li><li><a
                        href="#">Contact us</a></li>
            </ul>
        </div>
        <div class="footer_box footer_categories">
            <h6>Main Categories</h6>
            <ul>
                <li><a href="#">Logistics
                        companies</a></li><li><a
                        href="#">Travel
                        agencies</a></li><li><a
                        href="#">Construction
                        companies</a></li><li><a
                        href="#">Cleaning companies</a></li><li><a
                        href="#">IT companies</a></li>
            </ul>
        </div>
        <div class="footer_box">
            <h6>Database</h6>
            <ul id="ss"><li class="white"><span>00,810</span>Companies</li><li
                    class="white"><span class="white">00,291</span>Photos</li><li
                    class="white"><span class="white">00,094</span>Reviews</li><li
                    class="white"><span class="white">00,783</span>Products</li></ul>
        </div>
        <div class="clear"></div>
        <!-- <div class="social" id="bottom_fb_likes"><h6>People Like Us</h6><div
                class="fb-like" data-href="#"
                data-width="" data-layout="button_count"
                data-action="like" data-size="large" data-share="true"></div></div> -->
        <div class="social">
            <div class="clear"></div>
            <h6>Follow Us</h6>
            <a
                href="#"
                rel="noopener" target="_blank" aria-label="Facebook Fan
                Page"><i class="fa fa-facebook" aria-hidden="true"></i></a><a
                href="#" rel="noopener"
                target="_blank" aria-label="Twitter Page"><i class="fa
                    fa-twitter" aria-hidden="true"></i></a><a
                href="#"
                rel="noopener" target="_blank" aria-label="Linkedin
                Page"><i class="fa fa-linkedin" aria-hidden="true"></i></a><a
                href="#"
                rel="noopener" target="_blank" aria-label="Youtube
                Page"><i class="fa fa-youtube" aria-hidden="true"></i></a>
        </div>
        <div id="copyright" class="white">
            &copy; <?php echo date('Y'); ?> Developed By <a href="https://kyptronix.us"><span
                    class="white"> KYPTRONIX LLP</span></a>
        </div>
    </section>
</footer><div id="addthis_show" class="hidden"></div>
</body>

<!-- Mirrored from www.yello.ae/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 01 May 2023 05:23:46 GMT -->
</html><?php /**PATH C:\xampp\htdocs\LARAVEL-PROJECT\multiple-listing\resources\views/footer.blade.php ENDPATH**/ ?>