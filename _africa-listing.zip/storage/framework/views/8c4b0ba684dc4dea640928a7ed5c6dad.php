<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="top" style="background-color:aliceblue;">
        <section>
            <ul>
                <li><a href="https://www.yello.ae/jobs?utm_source=topjobs&amp;utm_medium=topjobslink"
                        title="Job Search UAE"><b>Jobs in UAE Today</b></a></li>
                <li><a href="https://www.yello.ae/real-estate?utm_source=topproperties&amp;utm_medium=toppropertieslinks"
                        title="Real Estate UAE"><b>Real Estate</b></a></li>
                <li><a href="https://www.yello.ae/public-holidays?utm_source=topholidays&amp;utm_medium=topholidayslinks"
                        title="Public Holidays UAE"><b>Public Holidays</b></a></li>
                <li><a href="https://www.yello.ae/lottery/big-ticket-result" title="Lotto Results UAE"><b>Lotto
                            Results</b></a></li>
                <li><a href="https://www.yello.ae/package-tracking" title="Package Tracking UAE"><b>Package
                            Tracking</b></a></li>
                <li><a href="https://www.yello.ae/" title="UAE Business Directory"><b>Business Directory</b></a></li>
            </ul>
        </section>
    </div>
    <main>
        <section>
            <div class="tp">
                <ul itemscope itemtype="https://schema.org/BreadcrumbList">
                    <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a
                            href="https://www.yello.ae/" itemprop="item"><span itemprop="name">Africa Listing </span></a>
                    </li>
                 
                        
                   
                    <li>Corporate Research &amp; Investigations LLC </li>
                </ul>
            </div>
            <h1>Corporate Research &amp; Investigations LLC </h1>
            <div>
                <div id="cmp_top" >
                    <div class="cmp_rate">
                        <div class="stars"><i class="fa fa-fw fa-star-o" aria-hidden="true"></i><i
                                class="fa fa-fw fa-star-o" aria-hidden="true"></i><i class="fa fa-fw fa-star-o"
                                aria-hidden="true"></i><i class="fa fa-fw fa-star-o" aria-hidden="true"></i><i
                                class="fa fa-fw fa-star-o" aria-hidden="true"></i></div>
                        <span class="rate">0.0</span>
                        <span class="reviews_count">0 Reviews</span>
                    </div>
                    <div class="cmp_buttons">
                        <a href="https://www.yello.ae/company/348518/corporate-researchinvestigations-llc/write-review"
                            class="review_button r_2px">Write a Review</a><a href="https://www.yello.ae/edit/348518"
                            class="update_button r_2px">Update Info</a>
                    </div>
                </div>
                <div class="ad728">
                    <ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-3351151485848212"
                        data-ad-slot="6480766417" data-ad-format="rectangle" data-full-width-responsive="true"></ins>
                    <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </div>
            </div>
            <div id="company_item">
                <div id="left">
                    <div id="cmp_nav" data-selected=".nav_home">
                        <div id="cmp_nav_line"></div>
                        <div id="cmp_nav_slider">
                            <nav>
                                <a href="https://www.yello.ae/company/348518/corporate-researchinvestigations-llc"
                                    class="nav_home">Contacts</a><a
                                    href="https://www.yello.ae/company/348518/corporate-researchinvestigations-llc#map"
                                    class="nav_map">Map</a><a
                                    href="https://www.yello.ae/company/348518/corporate-researchinvestigations-llc/products"
                                    class="nav_products">Products (5)</a><a
                                    href="https://www.yello.ae/company/348518/corporate-researchinvestigations-llc/send-enquiry"
                                    class="nav_send-enquiry" title="Send Enquiry">Send Enquiry</a>
                            </nav>
                        </div>
                    </div>
                    <div class="cmp_details">
                        <div class="cmp_details_in">
                            <div class="photos">
                                <div class="photos_in">
                                    <a href="https://www.yello.ae/img/ae/b/1518611946-41-corporate-research-investigations-llc.png"
                                        class="photo_href" title="Company photo"><img
                                            src="data:image/gif;base64,R0lGODlhAQABAIABAP///wAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
                                            data-src="/img/ae/b/_1518611946-41-corporate-research-investigations-llc.png"
                                            alt="" class="lazy-img r_3px" width="150"
                                            height="150"></a><a
                                        href="https://www.yello.ae/img/ae/z/1518611908-94-corporate-research-investigations-llc.jpg"
                                        class="photo_href" title="Company photo"><img
                                            src="data:image/gif;base64,R0lGODlhAQABAIABAP///wAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
                                            data-src="/img/ae/z/_1518611908-94-corporate-research-investigations-llc.jpg"
                                            alt="" class="lazy-img r_3px" width="150"
                                            height="150"></a><a
                                        href="https://www.yello.ae/img/ae/b/1481019464-42-corporate-research-investigations-llc.jpg"
                                        class="photo_href" title="Company photo"><img
                                            src="data:image/gif;base64,R0lGODlhAQABAIABAP///wAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
                                            data-src="/img/ae/b/_1481019464-42-corporate-research-investigations-llc.jpg"
                                            alt="" class="lazy-img r_3px" width="150"
                                            height="150"></a><a
                                        href="https://www.yello.ae/img/ae/z/1481019400-14-corporate-research-investigations-llc.jpg"
                                        class="photo_href" title="Company photo"><img
                                            src="data:image/gif;base64,R0lGODlhAQABAIABAP///wAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
                                            data-src="/img/ae/z/_1481019400-14-corporate-research-investigations-llc.jpg"
                                            alt="" class="lazy-img r_3px" width="150"
                                            height="150"></a><a
                                        href="https://www.yello.ae/img/ae/m/1432552531-92-corporate-research-investigations-llc.jpg"
                                        class="photo_href hidden" title="Company photo"><img
                                            src="data:image/gif;base64,R0lGODlhAQABAIABAP///wAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
                                            data-src="/img/ae/m/_1432552531-92-corporate-research-investigations-llc.jpg"
                                            alt="" class="lazy-img r_3px" width="150"
                                            height="150"></a><a
                                        href="https://www.yello.ae/company/348518/corporate-researchinvestigations-llc/gallery"
                                        id="photos_all" class="rounded_2px">+5</a>
                                </div>
                                <a href="https://www.yello.ae/company/348518/corporate-researchinvestigations-llc/upload"
                                    class="upload_button"><i class="fa fa-camera" aria-hidden="true"></i>Add a
                                    Photo</a>
                            </div>
                            <div class="cmp_marks">
                                <div class="cmp_marks_con">
                                    <div class="cmp_mark">
                                        <div class="vvv r_3px"><i class="fa fa-check"
                                                aria-hidden="true"></i><b>Verified</b><br />Listing</div>
                                    </div>
                                    <div class="cmp_mark">
                                        <div class="vvv r_3px"><i class="fa fa-trophy"
                                                aria-hidden="true"></i><b>PREMIUM</b><br />Member</div>
                                    </div>
                                    <div class="cmp_mark">
                                        <div class="vvv vvv2 r_3px"><i>+8</i><b>Years</b><br />With Us</div>
                                    </div>
                                </div>
                            </div>
                            <div class="info">
                                <div class="label">Company name</div><b id="company_name">Corporate Research &amp;
                                    Investigations LLC </b>
                            </div>
                            <div class="info">
                                <div class="label">Address</div>
                                <div class="text location">Liberty House , <a
                                        href="https://www.yello.ae/location/dubai" title="Companies in Dubai"
                                        class="city233">Dubai</a>, UAE<br /><a
                                        href="https://www.yello.ae/company/348518/corporate-researchinvestigations-llc#map"
                                        class="see_all">View Map <i class="fa fa-angle-down"
                                            aria-hidden="true"></i></a></div>
                            </div>
                            <div class="info">
                                <div class="label">Phone Number</div>
                                <div class="text phone">+971 4 3589884<br /></div>
                            </div>
                            <div class="info">
                                <div class="label">Mobile phone</div>
                                <div class="text">+971509038184<br /></div>
                            </div>
                            <div class="info">
                                <div class="label">Fax</div>
                                <div class="text">+971 4 3589094<br /></div>
                            </div>
                            <div class="info">
                                <div class="label">Website</div>
                                <div class="text weblinks"><a href="http://www.crigroup.com/" target="_blank"
                                        rel="noopener nofollow"
                                        onclick="$.post(&#039;/ajax/save_click/348518&#039;)">http://www.crigroup.com</a>
                                </div>
                            </div>
                            <div class="info oh r_3px"><span class="label">Working hours</span><br /><i
                                    class="fa fa fa-clock-o" aria-hidden="true"></i>Sunday: 24/7&nbsp;&nbsp;<a
                                    href="https://www.yello.ae/company/348518/corporate-researchinvestigations-llc#hours"
                                    class="see_all">See All <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                            </div>
                            <div class="info"><span class="label">Establishment year</span> 1990</div>
                            <div class="info"><span class="label">Employees</span> 51-100</div>
                            <div class="info"><span class="label">Company manager</span> Zafar Anjum </div>
                            <div class="info">
                                <div class="label">E-mail</div>
                                <div class="text"><a
                                        href="https://www.yello.ae/company/348518/corporate-researchinvestigations-llc/send-enquiry"
                                        title="Send Enquiry" class="blue_button send_email"><i
                                            class="fa fa-envelope-o" aria-hidden="true"></i>Send Enquiry</a></div>
                            </div>
                            <a href="https://www.yello.ae/jobs" class="blue_button send_email">Job Search</a>
                            <div class="info share_box">
                                <div class="label">Share this listing</div>
                                <div id="cmp_share">
                                    <div class="addthis_inline_share_toolbox"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="right">
                    <div class="ad600">
                        <ins class="adsbygoogle" style="display:inline-block;width:100%;height:600px"
                            data-ad-client="ca-pub-3351151485848212" data-max-num-ads="2"
                            data-ad-slot="9697273825"></ins>
                        <script>
                            (adsbygoogle = window.adsbygoogle || []).push({});
                        </script>
                    </div>
                </div>
                <div class="clear"></div>
                <a name="reviews"></a>
                <div class="info noreviews">
                    <h2>Reviews</h2>
                    <div class="general_rate">
                        <div class="stars"></div>
                        <div class="general_rate_t">0 Reviews</div>
                        <div class="clear"></div>
                        <div class="rate rate_0 rate_big">0.0</div>
                        <div class="rate_gap">&nbsp;</div><a
                            href="https://www.yello.ae/company/348518/corporate-researchinvestigations-llc/write-review"
                            class="blue_button">Write a Review</a>
                        <div class="clear"></div>
                    </div>
                    <div class="text">This company has no reviews. Be the first to share your experiences!</div>
                </div>
                <div class="info noreviews">
                    <h2>Questions & Answers</h2>
                    <div class="general_rate">
                        <div class="rate rate_big">0</div>
                        <div class="rate_gap">&nbsp;</div><a
                            href="https://www.yello.ae/company/348518/corporate-researchinvestigations-llc/qa#question_form"
                            class="blue_button">Ask a Question</a>
                        <div class="clear"></div>
                    </div>
                    <div class="text">Have questions? Get answers from Corporate Research & Investigations LLC or
                        Yello UAE users. Visitors haven’t asked any questions yet.</div>
                </div>
                <ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-3351151485848212"
                    data-ad-slot="3091354890" data-ad-format="auto" data-full-width-responsive="true"></ins>
                <script>
                    (adsbygoogle = window.adsbygoogle || []).push({});
                </script>
                <a name="map"></a>
                <h2>Company Details</h2>
                <div class="cmp_more">
                    <div class="info info_map">
                        <div class="label">Location map</div>
                        <div id="map_canvas" class="gm_canvas gm_bg r_3px" data-map-ltd="25.2088098361818"
                            data-map-lng="55.2773488476685" data-map-key="AIzaSyCJa7hHE89_JJ9LK4P_qfYD_o-Qc767Ii8"
                            data-map-autoload="0">
                            <a href="#" id="show_map">Show Map</a>
                        </div>
                        <div id="map_expander" class="hidden">Expand Map</div>
                        <div class="gray map_address">Liberty House , <a href="https://www.yello.ae/location/dubai"
                                title="Companies in Dubai" class="city233">Dubai</a>, UAE <a
                                href="https://maps.google.com/maps?daddr=25.2088098361818,55.2773488476685&amp;saddr="
                                id="map_dir_button" class="see_all see_all_long" rel="nofollow noopener"
                                target="_blank">Get Directions <i class="fa fa-external-link"
                                    aria-hidden="true"></i></a></div>
                    </div>
                    <div class="info">
                        <div class="label">Description</div>
                        <div class="text desc">For the past 25 years, Corporate Research and Investigations Private
                            Limited "CRI Group" has been safeguarding clients and major source of due diligence and
                            additional business investigations with positions and professional resources located in key
                            regional marketplaces across the Asia Pacific, South Asia, the Middle East and North Africa
                            by establishing the legal compliance, financial viability and integrity levels of outside
                            partners, suppliers, customers and other sources seeking potential business affiliations.
                            Today’s business climate and economic crises dictates an increasing demand for proactive
                            measures designed to reduce the exposure of international business organizations to economic
                            crime and civil wrongs, particularly in the financial, government and multinational business
                            sectors, “CRI Group's worldwide networks of multi-disciplined investigators help
                            organizations prevent and deter business crimes, employee malfeasance, threats and
                            accounting fraud while ensuring our clients conform to regulations, compliance and regional
                            laws such as the USA Patriot Act, the Foreign Corrupt Practices Act (FCPA), the Bank Secrecy
                            Act (BSA), Sarbanes-Oxley and others. CRI Group’s level of professional services spans fraud
                            risks Investigations, FCPA investigations; business intelligence and investigations;
                            employee, vendor and supplier background investigations; investigative due diligence and
                            “Know-Your-Client” inquiries; insurance fraud investigations; risk management and corporate
                            security consulting; and forensic accounting. CRIGROUP Key Specialties: Risk Management
                            Consulting Corporate Intelligence Investigative Due Diligence Fraud Risk Investigations
                            Fraud & White Collar Crime Insurance Fraud Investigations Corporate Security Consulting &
                            Investigations Business intelligence & Investigations Employment Screening & Background
                            Investigations Forensic Accounting & Investigations FCPA Due diligence Intellectual Property
                            Investigations - See more at:
                            http://www.yello.ae/company/348517/corporate-researchinvestigations-llc-qfc-branch#sthash.09eFX77o.dpuf
                        </div>
                    </div><a name="hours"></a>
                    <div class="info">
                        <div class="label">Working hours</div>
                        <div class="desc openinghours">
                            <table>
                                <tr>
                                    <th>Weekday</th>
                                    <th>Time</th>
                                </tr>
                                <tr>
                                    <td>Monday:</td>
                                    <td>24/7</td>
                                </tr>
                                <tr>
                                    <td>Tuesday:</td>
                                    <td>24/7</td>
                                </tr>
                                <tr>
                                    <td>Wednesday:</td>
                                    <td>24/7</td>
                                </tr>
                                <tr>
                                    <td>Thursday:</td>
                                    <td>24/7</td>
                                </tr>
                                <tr>
                                    <td>Friday:</td>
                                    <td>24/7</td>
                                </tr>
                                <tr>
                                    <td>Saturday:</td>
                                    <td>24/7</td>
                                </tr>
                                <tr class="current_day b">
                                    <td>Sunday:</td>
                                    <td>24/7</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <a name="products"></a>
                    <div class="info">
                        <div class="label">Products & Services</div>
                        <div class="product"><a href="https://www.yello.ae/product/6301/due-diligence"><img
                                    src="data:image/gif;base64,R0lGODlhAQABAIABAP///wAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
                                    data-src="/img/ae/a/1481019351_73789.jpg" alt="Due Diligence "
                                    class="lazy-img image r_3px" width="100" height="100"></a>
                            <div class="product_name b"><a href="https://www.yello.ae/product/6301/due-diligence"
                                    title="Due Diligence ">Due Diligence </a></div>CRI Group establishes the legal
                            compliance, financial viability and integrity levels of those outside partners, suppliers,
                            customers and other sources worldwide that seek potential affiliations with y...
                        </div>
                        <div class="product"><a
                                href="https://www.yello.ae/product/6302/background-investigations"><img
                                    src="data:image/gif;base64,R0lGODlhAQABAIABAP///wAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
                                    data-src="/img/ae/h/1481019337_32948.jpg" alt="Background Investigations"
                                    class="lazy-img image r_3px" width="100" height="100"></a>
                            <div class="product_name b"><a
                                    href="https://www.yello.ae/product/6302/background-investigations"
                                    title="Background Investigations">Background Investigations</a></div>The ability to
                            effectively pre-empt internal security issues and corporate crimes can save businesses from
                            huge potential losses and reputation damage. CRI Group’s background screening and
                            pre-employm...
                        </div>
                        <div class="product"><a
                                href="https://www.yello.ae/product/8465/3rd-part-risk-management-services"><img
                                    src="data:image/gif;base64,R0lGODlhAQABAIABAP///wAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
                                    data-src="/img/ae/f/1481019317_15703.jpg" alt="3rd Part Risk Management Services "
                                    class="lazy-img image r_3px" width="100" height="100"></a>
                            <div class="product_name b"><a
                                    href="https://www.yello.ae/product/8465/3rd-part-risk-management-services"
                                    title="3rd Part Risk Management Services ">3rd Part Risk Management Services </a>
                            </div>CRI Group’s own exclusive, expert-developed 3PRM services provide the very best in
                            third-party risk management. The 3PRM strategy provides a proactive approach to mitigating
                            risks from third-party aff...
                        </div>
                    </div><a href="https://www.yello.ae/company/348518/corporate-researchinvestigations-llc/products"
                        class="company_more">View all <strong>5</strong> products <i class="fa fa-long-arrow-right"
                            aria-hidden="true"></i></a><br />
                    <div class="info">
                        <div class="label">Listed in categories</div>
                        <div class="categories">
                            <a href="https://www.yello.ae/category/business-services"
                                title="Business Services Companies">Business Services</a><br /><a
                                href="https://www.yello.ae/category/human-resources"
                                title="Human Resources Companies">Business Services / Human Resources</a><br /><a
                                href="https://www.yello.ae/category/criminal-records-check"
                                title="Criminal Records Check Companies">Business Services / Human Resources / Criminal
                                Records Check</a><br /><a href="https://www.yello.ae/category/Employment-agencies"
                                title="Employment Agencies Companies">Business Services / Human Resources / Employment
                                Agencies</a><br /><a href="https://www.yello.ae/category/employee-surveys"
                                title="Employee Surveys Companies">Business Services / Human Resources / Employee
                                Surveys</a><br /><a href="https://www.yello.ae/category/private-investigation"
                                title="Private Investigation Companies">Business Services / Human Resources / Private
                                Investigation</a><br /><a href="https://www.yello.ae/category/market-research"
                                title="Market Research Companies">Business Services / Market Research</a><br /><a
                                href="https://www.yello.ae/category/consumer-behaviour"
                                title="Consumer Behaviour Companies">Business Services / Market Research / Consumer
                                Behaviour</a><br /><a href="https://www.yello.ae/category/legal"
                                title="Legal Companies">Legal</a><br /><a
                                href="https://www.yello.ae/category/legal-services"
                                title="Legal Services Companies">Legal / Legal Services</a><br /><a
                                href="https://www.yello.ae/category/accident-investigation"
                                title="Accident Investigation Companies">Legal / Legal Services / Accident
                                Investigation</a><br /><a href="https://www.yello.ae/category/detective-agencies"
                                title="Detective Agencies Companies">Legal / Legal Services / Detective
                                Agencies</a><br />
                        </div>
                    </div>
                    <div class="info">
                        <div class="label">Keywords</div>
                        <div class="tags"><a href="https://www.yello.ae/companies/3rd-party-risk-management"
                                class="">3rd Party Risk Management</a><a
                                href="https://www.yello.ae/companies/background-investigations"
                                class="">background investigations</a><a
                                href="https://www.yello.ae/companies/compliance" class="">Compliance</a><a
                                href="https://www.yello.ae/companies/due-diligence" class="">Due Diligence</a><a
                                href="https://www.yello.ae/companies/employee-background-screening"
                                class="">Employee Background Screening</a><a
                                href="https://www.yello.ae/companies/insurance-claim-investigations"
                                class="m_hidden">Insurance Claim Investigations</a><a
                                href="https://www.yello.ae/companies/integrityfcpa-due-diligence"
                                class="m_hidden">Integrity/FCPA/ Due Diligence</a><a
                                href="https://www.yello.ae/companies/public-record-searches" class="m_hidden">Public
                                Record Searches</a><a href="https://www.yello.ae/companies/risk-management"
                                class="m_hidden">Risk management</a><a href="#" class="m_visible rounded_2px"
                                id="tags_more">MORE +4</a>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="v_business r_3px">
                        <div class="v_gap"></div>
                        <div class="v_header">
                            <i class="fa fa-check" aria-hidden="true"></i>
                            <h3>Verified Business</h3>
                        </div>
                        <div class="text">Corporate Research & Investigations LLC - company profile is confirmed by
                            company owner / representative person / directory administrator.<br />Last update:
                            <strong>May 2016</strong> - <a
                                href="https://www.yello.ae/company/348518/corporate-researchinvestigations-llc/status"
                                rel="nofollow,noindex">View Status</a></div>
                        <div class="text">
                            <a href="https://www.yello.ae/edit/348518" rel="nofollow,noindex" class="blue_button"
                                title="Update Info Corporate Research & Investigations LLC ">Update Info</a> <a
                                href="https://www.yello.ae/contact-us/report:348518" rel="nofollow,noindex"
                                class="report_button">REPORT LISTING</a>
                        </div>
                    </div>
                    <div class="v_business r_3px">
                        <div class="v_gap v_gap_u"></div>
                        <div class="v_header">
                            <i class="fa fa-trophy" aria-hidden="true"></i>
                            <h3>Premium Member</h3>
                        </div>
                        <div class="text">Company profile registered as Lifetime.</div>
                    </div>
                </div>
                <h2>Frequently Asked Questions for Corporate Research &amp; Investigations LLC </h2>
                <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" class="review">
                    <div class="title" itemprop="name">What is Corporate Research &amp; Investigations LLC ’s phone
                        number?</div>
                    <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer" class="text">
                        <div itemprop="text">Corporate Research &amp; Investigations LLC ’s phone number is: +971 4
                            3589884 </div>
                    </div>
                </div>
                <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" class="review">
                    <div class="title" itemprop="name">What is Corporate Research &amp; Investigations LLC ’s
                        official website?</div>
                    <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer" class="text">
                        <div itemprop="text">Corporate Research &amp; Investigations LLC ’s official website is
                            http://www.crigroup.com</div>
                    </div>
                </div>
                <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" class="review">
                    <div class="title" itemprop="name">Where is Corporate Research &amp; Investigations LLC ’s
                        headquarters?</div>
                    <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer" class="text">
                        <div itemprop="text">Corporate Research &amp; Investigations LLC ’s headquarters are in Liberty
                            House , <a href="https://www.yello.ae/location/dubai" title="Companies in Dubai"
                                class="city233">Dubai</a>, UAE</div>
                    </div>
                </div>
                <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" class="review">
                    <div class="title" itemprop="name">Who is Corporate Research &amp; Investigations LLC ’s manager?
                    </div>
                    <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer" class="text">
                        <div itemprop="text">Corporate Research &amp; Investigations LLC ’s manager is Zafar Anjum
                        </div>
                    </div>
                </div>
                <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" class="review">
                    <div class="title" itemprop="name">What is location map of Corporate Research &amp;
                        Investigations LLC </div>
                    <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer" class="text">
                        <div itemprop="text">To see Corporate Research &amp; Investigations LLC ’s location map click
                            here <a href="https://www.yello.ae/company/348518/corporate-researchinvestigations-llc#map"
                                class="see_all">View Map</a></div>
                    </div>
                </div><br />
                <br />
                <ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-3351151485848212"
                    data-ad-slot="3091354890" data-ad-format="auto" data-full-width-responsive="true"></ins>
                <script>
                    (adsbygoogle = window.adsbygoogle || []).push({});
                </script>
                <div class="info"><br />
                    <h2>Related Companies to Corporate Research & Investigations LLC </h2><br />
                    <div class="company">
                        <h4><a href="https://www.yello.ae/company/358322/north-american-services-center"
                                title="North American Services Center">North American Services Center</a></h4>
                        <div class="address">Suite #203, Green Corner Building, Riqqa Road, Dubai, UAE, <a
                                href="https://www.yello.ae/location/dubai" title="Companies in Dubai"
                                class="city233 b">Dubai</a></div>
                        <div class="cont"><u class="v"><i class="fa fa-check" aria-hidden="true"></i>
                                &nbsp;Verified</u><u class="v v4"><b>+6</b> &nbsp;Years with us</u></div>
                        <div class="cont"><a
                                href="https://www.yello.ae/company/358322/north-american-services-center"
                                title="North American Services Center Business Page">
                                <div class="s"><i class="fa fa-phone" aria-hidden="true"></i><span>Phone</span>
                                </div>
                                <div class="s"><i class="fa fa-envelope"
                                        aria-hidden="true"></i><span>E-mail</span></div>
                                <div class="s"><i class="fa fa-map-marker"
                                        aria-hidden="true"></i><span>Map</span></div>
                                <div class="s"><i class="fa fa-globe"
                                        aria-hidden="true"></i><span>Website</span></div>
                                <div class="s"><i class="fa fa-picture-o" aria-hidden="true"></i> 1
                                    <span>Photos</span></div>
                                <div class="s"><i class="fa fa-rocket" aria-hidden="true"></i> 3
                                    <span>Products</span></div>
                            </a></div>
                        <div class="clear"></div>
                        <div class="company_reviews">
                            <div class="stars"></div>
                            <div class="rate">4.5</div>2 Reviews
                        </div><a href="https://www.yello.ae/company/358322/north-american-services-center"
                            class="m_company_link" aria-label="North American Services Center Listing"><i
                                class="fa fa-angle-right" aria-hidden="true"></i></a>
                    </div>
                    <div class="company">
                        <h4><a href="https://www.yello.ae/company/367720/bazaroo" title="Bazaroo">Bazaroo</a></h4>
                        <div class="address">Business Bay&#45; Tamani ART building, <a
                                href="https://www.yello.ae/location/dubai" title="Companies in Dubai"
                                class="city233 b">Dubai</a></div>
                        <div class="cont"><u class="v"><i class="fa fa-check" aria-hidden="true"></i>
                                &nbsp;Verified</u></div>
                        <div class="cont"><a href="https://www.yello.ae/company/367720/bazaroo"
                                title="Bazaroo Business Page">
                                <div class="s"><i class="fa fa-phone" aria-hidden="true"></i><span>Phone</span>
                                </div>
                                <div class="s"><i class="fa fa-envelope"
                                        aria-hidden="true"></i><span>E-mail</span></div>
                                <div class="s"><i class="fa fa-map-marker"
                                        aria-hidden="true"></i><span>Map</span></div>
                                <div class="s"><i class="fa fa-globe"
                                        aria-hidden="true"></i><span>Website</span></div>
                                <div class="s"><i class="fa fa-picture-o" aria-hidden="true"></i> 5
                                    <span>Photos</span></div>
                            </a></div>
                        <div class="clear"></div><a href="https://www.yello.ae/company/367720/bazaroo"
                            class="m_company_link" aria-label="Bazaroo Listing"><i class="fa fa-angle-right"
                                aria-hidden="true"></i></a>
                    </div>
                    <div class="company">
                        <h4><a href="https://www.yello.ae/company/317451/bha-accountancy-services"
                                title="BHA Accountancy Services">BHA Accountancy Services</a></h4>
                        <div class="address">Office 114, The Metropolis, Business Bay, <a
                                href="https://www.yello.ae/location/dubai" title="Companies in Dubai"
                                class="city233 b">Dubai</a></div>
                        <div class="cont"><u class="v"><i class="fa fa-check" aria-hidden="true"></i>
                                &nbsp;Verified</u><u class="v v4"><b>+10</b> &nbsp;Years with us</u></div>
                        <div class="cont"><a href="https://www.yello.ae/company/317451/bha-accountancy-services"
                                title="BHA Accountancy Services Business Page">
                                <div class="s"><i class="fa fa-phone" aria-hidden="true"></i><span>Phone</span>
                                </div>
                                <div class="s"><i class="fa fa-envelope"
                                        aria-hidden="true"></i><span>E-mail</span></div>
                                <div class="s"><i class="fa fa-map-marker"
                                        aria-hidden="true"></i><span>Map</span></div>
                                <div class="s"><i class="fa fa-globe"
                                        aria-hidden="true"></i><span>Website</span></div>
                                <div class="s"><i class="fa fa-picture-o" aria-hidden="true"></i> 1
                                    <span>Photos</span></div>
                                <div class="s"><i class="fa fa-rocket" aria-hidden="true"></i> 4
                                    <span>Products</span></div>
                            </a></div>
                        <div class="clear"></div>
                        <div class="company_reviews">
                            <div class="stars"></div>
                            <div class="rate">4.5</div>4 Reviews
                        </div><a href="https://www.yello.ae/company/317451/bha-accountancy-services"
                            class="m_company_link" aria-label="BHA Accountancy Services Listing"><i
                                class="fa fa-angle-right" aria-hidden="true"></i></a>
                    </div>
                    <div class="company">
                        <h4><a href="https://www.yello.ae/company/344405/contactopia"
                                title="Contactopia">Contactopia</a></h4>
                        <div class="address">SME&#45;01, Block&#45;C, SRTIP, Sharjah, <a
                                href="https://www.yello.ae/location/dubai" title="Companies in Dubai"
                                class="city233 b">Dubai</a></div>
                        <div class="cont"><u class="v"><i class="fa fa-check" aria-hidden="true"></i>
                                &nbsp;Verified</u><u class="v v4"><b>+9</b> &nbsp;Years with us</u><u
                                class="v v4"><i class="fa fa-bolt" aria-hidden="true"></i> &nbsp;Updated</u></div>
                        <div class="cont"><a href="https://www.yello.ae/company/344405/contactopia"
                                title="Contactopia Business Page">
                                <div class="s"><i class="fa fa-phone" aria-hidden="true"></i><span>Phone</span>
                                </div>
                                <div class="s"><i class="fa fa-envelope"
                                        aria-hidden="true"></i><span>E-mail</span></div>
                                <div class="s"><i class="fa fa-map-marker"
                                        aria-hidden="true"></i><span>Map</span></div>
                                <div class="s"><i class="fa fa-globe"
                                        aria-hidden="true"></i><span>Website</span></div>
                                <div class="s"><i class="fa fa-picture-o" aria-hidden="true"></i> 1
                                    <span>Photos</span></div>
                            </a></div>
                        <div class="clear"></div><a href="https://www.yello.ae/company/344405/contactopia"
                            class="m_company_link" aria-label="Contactopia Listing"><i class="fa fa-angle-right"
                                aria-hidden="true"></i></a>
                    </div>
                    <div class="company">
                        <h4><a href="https://www.yello.ae/company/356031/we-find-jobs" title="We Find Jobs">We Find
                                Jobs</a></h4>
                        <div class="address"> Al Sufouh &#45; Dubai Media City , <a
                                href="https://www.yello.ae/location/dubai" title="Companies in Dubai"
                                class="city233 b">Dubai</a></div>
                        <div class="cont"><u class="v"><i class="fa fa-check" aria-hidden="true"></i>
                                &nbsp;Verified</u><u class="v v4"><b>+6</b> &nbsp;Years with us</u></div>
                        <div class="cont"><a href="https://www.yello.ae/company/356031/we-find-jobs"
                                title="We Find Jobs Business Page">
                                <div class="s"><i class="fa fa-phone" aria-hidden="true"></i><span>Phone</span>
                                </div>
                                <div class="s"><i class="fa fa-envelope"
                                        aria-hidden="true"></i><span>E-mail</span></div>
                                <div class="s"><i class="fa fa-map-marker"
                                        aria-hidden="true"></i><span>Map</span></div>
                                <div class="s"><i class="fa fa-globe"
                                        aria-hidden="true"></i><span>Website</span></div>
                                <div class="s"><i class="fa fa-picture-o" aria-hidden="true"></i> 1
                                    <span>Photos</span></div>
                                <div class="s"><i class="fa fa-rocket" aria-hidden="true"></i> 2
                                    <span>Products</span></div>
                            </a></div>
                        <div class="clear"></div>
                        <div class="company_reviews">
                            <div class="stars"></div>
                            <div class="rate">5.0</div>62 Reviews
                        </div><a href="https://www.yello.ae/company/356031/we-find-jobs" class="m_company_link"
                            aria-label="We Find Jobs Listing"><i class="fa fa-angle-right"
                                aria-hidden="true"></i></a>
                    </div>
                    <div class="company">
                        <h4><a href="https://www.yello.ae/company/344500/yuga-accountingtax-consultancy"
                                title="Yuga Accounting &amp; Tax Consultancy">Yuga Accounting &amp; Tax Consultancy</a>
                        </h4>
                        <div class="address">INTERNATIONAL CITY, DUBAI, UAE, <a
                                href="https://www.yello.ae/location/dubai" title="Companies in Dubai"
                                class="city233 b">Dubai</a></div>
                        <div class="cont"><u class="v"><i class="fa fa-check" aria-hidden="true"></i>
                                &nbsp;Verified</u><u class="v v4"><b>+9</b> &nbsp;Years with us</u></div>
                        <div class="cont"><a
                                href="https://www.yello.ae/company/344500/yuga-accountingtax-consultancy"
                                title="Yuga Accounting &amp; Tax Consultancy Business Page">
                                <div class="s"><i class="fa fa-phone" aria-hidden="true"></i><span>Phone</span>
                                </div>
                                <div class="s"><i class="fa fa-envelope"
                                        aria-hidden="true"></i><span>E-mail</span></div>
                                <div class="s"><i class="fa fa-map-marker"
                                        aria-hidden="true"></i><span>Map</span></div>
                                <div class="s"><i class="fa fa-globe"
                                        aria-hidden="true"></i><span>Website</span></div>
                                <div class="s"><i class="fa fa-picture-o" aria-hidden="true"></i> 4
                                    <span>Photos</span></div>
                                <div class="s"><i class="fa fa-rocket" aria-hidden="true"></i> 3
                                    <span>Products</span></div>
                            </a></div>
                        <div class="clear"></div>
                        <div class="company_reviews">
                            <div class="stars"></div>
                            <div class="rate">4.9</div>14 Reviews
                        </div><a href="https://www.yello.ae/company/344500/yuga-accountingtax-consultancy"
                            class="m_company_link" aria-label="Yuga Accounting &amp; Tax Consultancy Listing"><i
                                class="fa fa-angle-right" aria-hidden="true"></i></a>
                    </div>
                    <div class="company">
                        <h4><a href="https://www.yello.ae/company/344639/permits-and-visas"
                                title="Permits and Visas">Permits and Visas</a></h4>
                        <div class="address">Office # 2402 Smart Heights Tower, TECOM, Dubai, UAE, <a
                                href="https://www.yello.ae/location/dubai" title="Companies in Dubai"
                                class="city233 b">Dubai</a></div>
                        <div class="cont"><u class="v"><i class="fa fa-check" aria-hidden="true"></i>
                                &nbsp;Verified</u><u class="v v4"><b>+9</b> &nbsp;Years with us</u></div>
                        <div class="cont"><a href="https://www.yello.ae/company/344639/permits-and-visas"
                                title="Permits and Visas Business Page">
                                <div class="s"><i class="fa fa-phone" aria-hidden="true"></i><span>Phone</span>
                                </div>
                                <div class="s"><i class="fa fa-envelope"
                                        aria-hidden="true"></i><span>E-mail</span></div>
                                <div class="s"><i class="fa fa-map-marker"
                                        aria-hidden="true"></i><span>Map</span></div>
                                <div class="s"><i class="fa fa-globe"
                                        aria-hidden="true"></i><span>Website</span></div>
                                <div class="s"><i class="fa fa-picture-o" aria-hidden="true"></i> 1
                                    <span>Photos</span></div>
                            </a></div>
                        <div class="clear"></div>
                        <div class="company_reviews">
                            <div class="stars"></div>
                            <div class="rate">4.4</div>66 Reviews
                        </div><a href="https://www.yello.ae/company/344639/permits-and-visas" class="m_company_link"
                            aria-label="Permits and Visas Listing"><i class="fa fa-angle-right"
                                aria-hidden="true"></i></a>
                    </div>
                    <div class="company">
                        <h4><a href="https://www.yello.ae/company/356172/alliance-recruitment-agency"
                                title="Alliance Recruitment Agency">Alliance Recruitment Agency</a></h4>
                        <div class="address">Al Seef tower, Marina, <a href="https://www.yello.ae/location/dubai"
                                title="Companies in Dubai" class="city233 b">Dubai</a></div>
                        <div class="cont"><u class="v"><i class="fa fa-check" aria-hidden="true"></i>
                                &nbsp;Verified</u><u class="v v4"><b>+6</b> &nbsp;Years with us</u><u
                                class="v v4"><i class="fa fa-bolt" aria-hidden="true"></i> &nbsp;Updated</u></div>
                        <div class="cont"><a href="https://www.yello.ae/company/356172/alliance-recruitment-agency"
                                title="Alliance Recruitment Agency Business Page">
                                <div class="s"><i class="fa fa-phone" aria-hidden="true"></i><span>Phone</span>
                                </div>
                                <div class="s"><i class="fa fa-envelope"
                                        aria-hidden="true"></i><span>E-mail</span></div>
                                <div class="s"><i class="fa fa-globe"
                                        aria-hidden="true"></i><span>Website</span></div>
                                <div class="s"><i class="fa fa-picture-o" aria-hidden="true"></i> 1
                                    <span>Photos</span></div>
                            </a></div>
                        <div class="clear"></div>
                        <div class="company_reviews">
                            <div class="stars"></div>
                            <div class="rate">5.0</div>8 Reviews
                        </div><a href="https://www.yello.ae/company/356172/alliance-recruitment-agency"
                            class="m_company_link" aria-label="Alliance Recruitment Agency Listing"><i
                                class="fa fa-angle-right" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
            <div id="related">
                <h2 class="def_h2">Search Results Related to Corporate Research &amp; Investigations LLC </h2>
                <div class="tags">
                    <a href="https://www.yello.ae/category/human-resources/city:dubai">Human Resources in Dubai</a><a
                        href="https://www.yello.ae/category/criminal-records-check/city:dubai">Criminal Records Check
                        in Dubai</a><a href="https://www.yello.ae/category/Employment-agencies/city:dubai">Employment
                        Agencies in Dubai</a><a
                        href="https://www.yello.ae/category/employee-surveys/city:dubai">Employee Surveys in
                        Dubai</a><a href="https://www.yello.ae/category/private-investigation/city:dubai">Private
                        Investigation in Dubai</a><a
                        href="https://www.yello.ae/category/market-research/city:dubai">Market Research in Dubai</a><a
                        href="https://www.yello.ae/category/consumer-behaviour/city:dubai">Consumer Behaviour in
                        Dubai</a><a href="https://www.yello.ae/category/legal-services/city:dubai">Legal Services in
                        Dubai</a><a href="https://www.yello.ae/category/accident-investigation/city:dubai">Accident
                        Investigation in Dubai</a><a
                        href="https://www.yello.ae/category/detective-agencies/city:dubai">Detective Agencies in
                        Dubai</a>
                </div>
            </div>
            <div class="clear"></div><br />
            <ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-3351151485848212"
                data-ad-slot="3091354890" data-ad-format="auto" data-full-width-responsive="true"></ins>
            <script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
            <div class="invitation_to_list">
                <h2 class="def_h2">Similiar Page for Your Business?</h2>
                <div class="text">Make sure everyone can find your business online. Create your dedicated company
                    page on <b>Yello UAE</b> - it's simply and easy!</div><br />
                <a href="https://www.yello.ae/create-business-listing" class="blue_button">List Your Business</a>
            </div>
            <br />
            <div class="small">C2023-04-23</div>
        </section>
    </main>
    <div id="loading"><i class="fa fa-cog fa-spin fa-3x fa-fw"></i></div>
    <div id="fb-root"></div>
    <a href="#nav-top" id="back_to_top">BACK TO TOP&nbsp;&nbsp;<i class="fa fa-angle-double-up"
            aria-hidden="true"></i></a>
  <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL-PROJECT\multiple-listing\resources\views/listing.blade.php ENDPATH**/ ?>