<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <main>
        <section>
            <div class="tp">
                <ul itemscope itemtype="javascript:void(0)">
                    <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a
                            href="javascript:void(0)" itemprop="item"><span itemprop="name">Africa</span></a>
                        <meta itemprop="position" content="1" />
                    </li>
                    <li itemprop="itemListElement" itemscope itemtype="javascript:void(0)"><a
                            href="javascript:void(0)" itemprop="item"><span
                                itemprop="name">Categories</span></a>
                        <meta itemprop="position" content="2" />
                    </li>
                    <li itemprop="itemListElement" itemscope itemtype="javascript:void(0)"><a
                            href="javascript:void(0)" itemprop="item"><span itemprop="name">Listings</span></a>
                        <meta itemprop="position" content="3" />
                    </li>
                    <li itemprop="itemListElement" itemscope itemtype="javascript:void(0)"><a
                            href="javascript:void(0)" itemprop="item"><span itemprop="name"><?php echo e($category_name->category_name); ?></span></a>
                        <meta itemprop="position" content="4" />
                    </li>
                </ul>
            </div>
            <h1>Best <?php echo e($category_name->category_name); ?>s in Africa</h1>
            <div id="page_text">Looking for <strong>Best <?php echo e($category_name->category_name); ?></strong> in Africa .</div>
            <div id="filters" data-selected=".cat678">
                <h5 class="r_2px"><a href="#">Filter by Country <i class="fa fa-caret-down"
                            aria-hidden="true"></i></a></h5>
                <div class="cats m_hidden">
                    
                    <ul>
                        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url('category/country/listing')); ?>/<?php echo e($all_country->country); ?>" class="city233"><?php echo e($all_country->country); ?></a></li>
                     
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </ul>
                </div>
                <h5 class="r_2px"><a href="#">All Categories <i class="fa fa-caret-down"
                            aria-hidden="true"></i></a></h5>
                <div class="cats m_hidden">
                    <ul>
                        
                      <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><a href="<?php echo e(url('/category/listing/')); ?>/<?php echo e($all_category->id); ?>" class="cat2471"> <?php echo e($all_category->category_name); ?></a></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                  
                    </ul>
                </div>
                
            </div>

            <div id="listings">
                <div class="ad336">
                    <ins class="adsbygoogle asas" style="display:block" data-ad-client="ca-pub-3351151485848212"
                        data-ad-slot="3758602228" data-max-num-ads=2 data-ad-format="rectangle"></ins>
                </div>
                <div id="page_text_m">Looking for <strong>Best Real Estate Agents</strong> in Africa ? Find the list of Top
                    Best Real Estate Agents in UAE on our business directory. Best Real Estate Agents near me.</div>
                <div class="pages_container_top">We found <strong><?php echo e($count); ?></strong> companies</div>
               


        <?php if(count($data)>0): ?>
        <?php
        $i=1;
        ?>

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="company with_img g_3" id="cmap_0">
            <h4><a href="<?php echo e(url('listing')); ?>/<?php echo e($listings->listing_id); ?>" title="Bazaroo"><?php echo e($listings->listing_title); ?></a></h4>
            <div class="address">Location &#45; <?php echo e($listings->address); ?></div>
            <div class="details">
                <div class="desc"><?php echo e($listings->website); ?></div><a href="<?php echo e(url('listing')); ?>/<?php echo e($listings->listing_id); ?>"
                    class="logo" title="Bazaroo Business Page"><span itemprop="image" itemscope
                        itemtype="http://schema.org/ImageObject">
                        <meta itemprop="url"
                            content="https://www.yello.ae/img/ae/s/1643103557-99-bazaroo.jpg"><img
                            src="<?php echo e(url('listing_photo')); ?>/<?php echo e($listings->photo); ?>"
                            data-src="/img/ae/s/_1643103557-99-bazaroo.jpg" alt="Bazaroo"
                            class="lazy-img r_3px" width="80" height="80"></a>
            </div>
            <div class="cont"><u class="v"><i class="fa fa-check" aria-hidden="true"></i>
                    &nbsp;Verified</u></div>
            <div class="cont"><a href="<?php echo e(url('listing')); ?>/<?php echo e($listings->listing_id); ?>" title="Bazaroo Business Page">
                    <div class="s"><i class="fa fa-phone" aria-hidden="true"></i><span>Phone</span>
                    </div>
                    <div class="s"><i class="fa fa-envelope" aria-hidden="true"></i><span>E-mail</span>
                    </div>
                    <div class="s"><i class="fa fa-map-marker" aria-hidden="true"></i><span>Map</span>
                    </div>
                    <div class="s"><i class="fa fa-globe" aria-hidden="true"></i><span>Website</span>
                    </div>
                    
                </a></div>
            <div class="clear"></div><a href="<?php echo e(url('listing')); ?>/<?php echo e($listings->listing_id); ?>" class="mapmarker" data-ltd="25.187424"
                data-lng="55.281025" data-key="0" title="Company #1 Location on Map"><?php echo e($i++); ?></a>
        </div> <br>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <div style="padding:15px; background-color:antiquewhite">
            <h4 style="text-align:center">Listing Not Found</h4>
        </div>
        <?php endif; ?>
        <div>
            <?php echo e($data->links()); ?>

        </div>

            



                <div class="ad336_b">
                    <ins class="adsbygoogle asas" style="display:block" data-ad-client="ca-pub-3351151485848212"
                        data-ad-slot="8959911556" data-max-num-ads=3 data-ad-format="rectangle"></ins>
                    <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </div>

                <div class="pages_container">
                
                </div>


                <div class="suggest">
                    <h6>Didn't find what you were looking for?</h6>
                    <div class="text">Tell us what is missing</div><br /><a href="<?php echo e(url('user/add-listing')); ?>"
                        class="blue_button">Add Business</a><br /><br />
                    <h6>Do you like this list?</h6>
                    <!--<div class="text">That's great to hear! If you're satisfied with the <?php echo e($category_name->category_name); ?> listing  . that's what matters the most. It's important to have messaging that resonates with your target audience and effectively communicates the value and benefits of your platform. If you have any further questions or need assistance with anything else, feel free to ask. -->
                    <!--</div> -->
                    <br>
                    <div class="text">Share the link with others:</div><br /><a
                        href="javascript:void(0)"
                        rel="noopener" title="Share the List on Facebook" onclick="Copy();"><i
                            class="fa fa-facebook" aria-hidden="true"></i></a><a
                        href="javascript:void(0)"
                        rel="noopener" title="Share the List on Linkedin" onclick="Copy();"><i
                            class="fa fa-linkedin" aria-hidden="true"></i></a><a
                        href="javascript:void(0)"
                        rel="noopener" title="Share the List on Twitter" onclick="Copy();"><i
                            class="fa fa-twitter" aria-hidden="true"></i></a>
                    <div class="clear"></div>
                </div>
                <h6> Searched categories</h6><br />
                <div class="tags">
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(url('category/listing')); ?>/<?php echo e($cats->id); ?>" title=""><?php echo e($cats->category_name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <div id="url"></div>
                        
                        
                       </div>
                <div class="clear"></div>
            </div>
            <div id="mapslider_con" class="m_hidden">
                <div id="mapslider">
                    <div class="" style="width:10px height:150px; display:flex; justify-content:center; align-items:center; margin-top:50px; ">
                        <img src="<?php echo e(url('mobile.gif')); ?>" style ="width:300px; height:300px;" alt=""></div>
                   <div class="" style="width:10px height:150px; display:flex; justify-content:center; align-items:center; margin-top:50px; ">
                <img src="<?php echo e(url('location.gif')); ?>" style ="width:200px; height:200px;" alt=""></div>
              
                </div>
            </div>
            <div class="clear"></div>
        </section>
    </main>
    <div id="m_map" class="gm_canvas fullscreen hidden"></div>
    <div id="loading"><i class="fa fa-cog fa-spin fa-3x fa-fw"></i></div>
    <div id="fb-root"></div>
    <a href="#nav-top" id="back_to_top" style="color:white;"><b>BACK TO TOP</b>
        &nbsp;&nbsp;<i class="fa
            fa-angle-double-up" aria-hidden="true"></i></a>
  <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script>
    function Copy(){

  $("#copy").val(window.location.href).select();
          // Get the URL
    var url = window.location.href;

    // Create a temporary input element
    var input = $('<input>');
    $('body').append(input);

    // Set the value of the input to the URL
    input.val(url).select();

    // Copy the URL to the clipboard
    document.execCommand('copy');

    // Remove the temporary input element
    input.remove();

    // Provide some visual feedback
      swal("URL Copied..");
 
    }
  </script><?php /**PATH C:\xampp\htdocs\LARAVEL_PROJECTS\africa\resources\views/category-listing.blade.php ENDPATH**/ ?>