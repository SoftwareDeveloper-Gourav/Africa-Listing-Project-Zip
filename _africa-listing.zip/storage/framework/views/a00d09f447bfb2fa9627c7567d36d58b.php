<!DOCTYPE html>
<html lang="en">

    <!-- Mirrored from www.yello.ae/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 01 May 2023 05:23:06 GMT -->
    <head><meta charset="utf-8" /><meta http-equiv="Content-Language"
            content="en" />
        <meta name="viewport" content="initial-scale=1, maximum-scale=1,
            minimum-scale=1, user-scalable=0, width=device-width"><meta
            http-equiv="X-UA-Compatible" content="IE=edge" />
        <title>Africa Business Directory - List of Companies in Africa</title>
        <meta name="description" content="Business Directory Africa, List of
            Companies in Africa with Contact Details, Addresses. Africa
            Companies, Africa
            Directory Listing." /><link rel="stylesheet" type="text/css"
            href="css/main.mina2f7.css?v=556" />
        <link rel="shortcut icon" href="favs/y-96.png" type="image/png"
            sizes="96x96" type="image/png" /><link rel="stylesheet"
            type="text/css" href="css/index.mina2f7.css?v=556" />
        <link rel="manifest" href="manifest/aemanifest.json">
        <link rel="apple-touch-icon" href="favs/y/icon-192x192.png">
        <meta name="msapplication-config" content="none" />
        <meta name="theme-color" content="#7fc6c8">
        <meta name="msapplication-navbutton-color" content="#7fc6c8">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <link rel="preconnect" href="https://ajax.googleapis.com/"><link
            rel="preconnect" href="https://maxcdn.bootstrapcdn.com/"><link
            rel="preconnect" href="https://googleads.g.doubleclick.net/">
        <link rel="alternate" type="application/rss+xml" title="Africa Business
            Directory Feed" href="rss.html">
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js" type="text/javascript"></script><![endif]-->
        <meta
            property="og:image"
            content="https://www.yello.ae/img/site/index/ae-fb.jpg?v=3" />
        <meta property="og:title" content="Africa Business Directory - List of
            Companies in Africa" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.yello.ae" />
        <meta property="fb:app_id" content="1360649584020818" />
        <style>
            .white{
                color:white;
            }
            #back_to_top, #top{
                background-color: #901a14;
            }
        </style>
    </head>
    <body>
        <!-- img/site/index/ae.jpg -->
        <a id="nav-top"></a>
        <div class="heading" id="index_heading" style="background-image:
            url('img/banner3.jpg')" data-drop-search="0">
            <nav>
                <a href="#" title="Africa Business Directory - Yello Africa"
                    class="logo_link logo_yello" style="background-image:
                    url('img/africa-logo.png'); background-size: 103px;">Africa
                    Business Directory -
                    Yello Africa</a> <div class="userbox userbox_en">
                    <div id="userbox_menu" style="background-color: #780026;">
                        <a href="<?php echo e(url('/user')); ?>">Sign in</a> <a
                            href="#" title="Add
                            Business" class="add_business r_2px">Add Business</a>
                    </div>
                    <a href="#" class="m_header_link m_menu_link"
                        aria-label="Show navbar" data-ajaxload="0">
                        <i class="fa fa-bars" aria-hidden="true"></i>
                    </a>
                </div>
                <div id="dm">
                    <div id="dm_in">
                        <div class="dm_nav"><a href="#" title="Sign
                                in" class="add_business user_signin r_20px">Sign
                                in</a><div class="dm_label"><b>Business
                                    Directory</b></div><a href="#">Africa
                                Business Directory</a><a
                                href="#">Browse
                                Categories</a><a
                                href="#">Browse
                                Locations</a><a href="#">Public
                                Holidays 2023</a><a href="#">Contact
                                us</a><a href="#"
                                class="add_business2 r_20px">+ Add Business</a><div
                                class="dm_label"><b>Jobs</b></div><a
                                href="#">Jobs in Africa Today</a><a
                                href="#">Accounting Jobs</a><a
                                href="#">Sales Jobs</a><a
                                href="#">Internship
                                Jobs</a><a href="#"
                                class="add_business2 r_20px">+ Post a Job</a><div
                                class="dm_label"><b>Real Estate</b></div><a
                                href="#">Real Estate in Africa</a><a
                                href="#">Available Properties</a><a
                                href="#"
                                class="add_business2 r_20px">+ LIST PROPERTY</a><div
                                class="dm_label"><b>Big Ticket</b></div><a
                                href="#">Big Ticket
                                Result</a><a
                                href="#">Big Ticket
                                Past Result</a><div class="dm_label"><b>Package
                                    Tracking</b></div><a
                                href="#">Track Your Package</a></div><br
                            /><br />
                    </div>
                    <a href="#" id="userbox_close" class="dm_close"
                        aria-label="Close navbar"><i class="fa fa-window-close"
                            aria-hidden="true"></i></a></div>
                <h1><span>Welcome to</span> Africa Business Directory</h1> <div
                    class="s_box">
                    <form id="search_form" data-autocomplete-loaded="0"
                        method="post"
                        action="https://www.yello.ae/Africa-business-search"><fieldset
                            style="display:none;"><input type="hidden"
                                name="_method" value="POST" /></fieldset>
                        <div class="input text"><input
                                name="data[CompanySearch][query]" type="text"
                                placeholder="Search for Companies or Services"
                                autocorrect="off" autocomplete="off"
                                maxlength="40" class="highlight" value=""
                                id="CompanySearchQuery" /></div>
                        <div class="input text"><input
                                name="data[CompanySearch][location]" type="text"
                                placeholder="Location" autocorrect="off"
                                autocomplete="off" maxlength="40" value=""
                                id="CompanySearchLocation" /></div>
                        <a href="#" class="s_submit" aria-label="Search"><i
                                class="fa fa-search" aria-hidden="true"></i></a>
                        <a href="#"
                            class="browse_submit">Browse Categories</a>
                        <input type="submit" class="hidden" value="Search" />
                    </form>
                    <a href="#" id="s_close" class="dm_close hidden"><i
                            class="fa fa-window-close" aria-hidden="true"></i></a>
                </div>
                <a href="#" id="m_search_link" class="m_header_link m_visible"
                    title="Companies Search"><i class="fa fa-search"
                        aria-hidden="true"></i></a>
                <div id="s_drop"></div> </nav>
            <div id="top" class="hidden"></div>
            <div class="iholder">

                <div class="icategories">

                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <a href="<?php echo e(url('category/listing')); ?>/<?php echo e($category_data->id); ?>" class="cat_restaurants">
                        <img src="<?php echo e(url('category_icon')); ?>/<?php echo e($category_data->category_icon); ?>" alt="" width="45px" height="45px"> 
                        <p><?php echo e($category_data->category_name); ?></p>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
                            
       <?php if(count($category)>8): ?>{
        <a href="#" class="cat_more">
            <i class="fa fa-ellipsis-h" aria-hidden="true"></i>See All
        </a> 
       }
       <?php endif; ?>


                    
                    </div>
            </div>
        </div>

        <div class="grey_container">
            <h2 class="simpleh2">Maximize Your Business <span
                    style="color:#a72a14;">Online Marketing</span> </h2>
            <section>
                <div class="ibusiness">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Natus veritatis quasi, nobis temporibus fugit, vitae
                    eligendi, aut nulla provident praesentium amet optio cum
                    sapiente facilis. <br /><br />
                    <a href="#" class="iregister
                        r_2px">List Your Business</a>
                </div>
            </section>
        </div>
        <section>
            <div class="container-fluid">
                <h2 class="h2_feedbacks">What do Company <span
                        style="color:#a72a14;">Owners Say?</span> </h2>
                <div class="feedbacks">
                    <div class="feedback"><div class="text r_3px">Lorem ipsum
                            dolor sit amet consectetur velit recusandae! nam?</div><div
                            class="arrow-down"></div><div
                            class="company_link company_link_in_list"><div
                                class="image" style="background-image:
                                url(img/ae/z/_1567406064-26-digitalopment.jpg);
                                background-size: cover;"></div><a
                                href="#"
                                title="Digitalopment">Digitalopment</a></div></div><div
                        class="feedback"><div class="text r_3px">Lorem ipsum
                            dolor sit amet consectetur velit recusandae! nam?</div><div
                            class="arrow-down"></div><div class="company_link
                            company_link_in_list"><div class="image"
                                style="background-image:
                                url(img/ae/a/1396525360_67514.jpg);
                                background-size:
                                cover;"></div><a
                                href="#" title="ARRIVO
                                LLC ">ARRIVO LLC </a></div></div><div
                        class="feedback"><div class="text r_3px">Lorem ipsum
                            dolor sit amet consectetur velit recusandae! nam?
                        </div><div class="arrow-down"></div><div
                            class="company_link
                            company_link_in_list"><div class="image"
                                style="background-image:
                                url(img/ae/f/_1434894028-42-gqpowertools.jpg);
                                background-size: cover;"></div><a
                                href="#"
                                title="GQPowerToolsAfrica">GQPowerToolsAfrica</a></div></div><div
                        class="clear"></div>
                    <a href="#" class="feedbacks_more">See All 176</a>
                </div>
            </div>
        </section>
        <div id="ibanner">
            <ins class="adsbygoogle" style="display:block"
                data-ad-client="ca-pub-3351151485848212"
                data-ad-slot="5716400618" data-ad-format="auto"
                data-full-width-responsive="true"></ins>
            <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
        </div>
        <section>
            <h2 class="h2_locations">Browse <span style="color:#a72a14;">
                    Locations</span></h2>
            <ul class="icats">
                 <?php $__currentLoopData = $listing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <li><a href="#" title="List of
                    Companies in Dubai"><?php echo e($listing_data->address); ?></a></li>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                        
                     <?php if(count($listing)>7): ?>
                     <li><a
                        href="#" title="View all
                        cities" class="icats_more">See All <span><i class="fa
                                fa-long-arrow-right" aria-hidden="true"></i></span></a></li>
                                <?php endif; ?>
                            
                            
                            </ul>
            <div class="clear"></div>
        </section>
        <br />
        <section>
            <h2 class="h2_cats">Top <span style="color:#a72a14;">
                    Categories</span></h2>
            <ul class="icats">
              <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categor_data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><a
                href="<?php echo e(url('/category/listing/')); ?>/<?php echo e($categor_data2->id); ?>"
                title=""><?php echo e($categor_data2->category_name); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                       
                       <?php if(count($category)>5): ?>
                       <li><a
                        href="#"
                        class="icats_more">See All <span><i class="fa
                                fa-long-arrow-right" aria-hidden="true"></i></span></a></li>
                                <?php endif; ?>
                            </ul>
            <div class="clear"></div>
        </section>
        <section>
            <h2 class="h2_updates">New and <span style="color:#a72a14;">Updated
                    Companies</span></h2>
            <ul class="iup">
               <?php $__currentLoopData = $listing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing_data3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               <li><div class="iup_item"><div class="updated
                r_2px">UPDATED</div><div class="aright gray"><small>29
                    Apr, 2023</small></div><a
                href="#" title="Ajeets
                Africa"> <?php echo e($listing_data3->listing_title); ?></a></div></li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                           
                            <?php if(count($listing)>5): ?>
                                <li><a
                                    href="#" title="View all
                                    new/updated companies" class="icats_more">See All <span><i
                                            class="fa fa-long-arrow-right"
                                            aria-hidden="true"></i></span></a></li>
                            <?php endif; ?>
                            
                            </ul>
            <div class="clear"></div>
        </section>
        <section><h2 class="h2_sites">More Our Websites</h2> <ul class="icats"><li><a href="https://www.yellosa.co.za/" rel="noopener" target="_blank" title="South Africa Business Directory">South Africa<span class="wi">yellosa.co.za</span></a></li><li><a href="https://www.ghanayello.com/" rel="noopener" target="_blank" title="Ghana Business Directory">Ghana<span class="wi">ghanayello.com</span></a></li><li><a href="https://www.businesslist.com.ng/" rel="noopener" target="_blank" title="Nigeria Business Directory">Nigeria<span class="wi">businesslist.com.ng</span></a></li><li><a href="https://www.businesslist.co.ke/" rel="noopener" target="_blank" title="Kenya Business Directory">Kenya<span class="wi">businesslist.co.ke</span></a></li><li><a href="https://www.businesslist.ph/" rel="noopener" target="_blank" title="Philippines Business Directory">Philippines<span class="wi">businesslist.ph</span></a></li><li><a href="https://www.businesslist.my/" rel="noopener" target="_blank" title="Malaysia Business Directory">Malaysia<span class="wi">businesslist.my</span></a></li><li><a href="https://www.jamaicaindex.com/" rel="noopener" target="_blank" title="Jamaica Business Directory">Jamaica<span class="wi">jamaicaindex.com</span></a></li><li><a href="https://www.businesslist.pk/" rel="noopener" target="_blank" title="Pakistan Business Directory">Pakistan<span class="wi">businesslist.pk</span></a></li><li><a href="https://www.saudiayp.com/" rel="noopener" target="_blank" title="Saudi Arabia Business Directory">Saudi Arabia<span class="wi">saudiayp.com</span></a></li></ul><div class="clear"></div></section>
        <section><div id="index_fb_iframe"><div class="fb-page"
                    data-href="https://www.facebook.com/Dubai-I-love-You-867548599961003"
                    data-width="300" data-height="215" data-small-header="true"
                    data-adapt-container-width="true" data-hide-cover="false"
                    data-show-facepile="true" data-show-posts="false"></div></div><script>(function(d, s, id) {var js, fjs = d.getElementsByTagName(s)[0];if (d.getElementById(id)) return;js = d.createElement(s); js.id = id;js.src = "../connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=207398209303117";fjs.parentNode.insertBefore(js, fjs);}(document, 'script', 'facebook-jssdk'));</script></section>
        <div id="loading"><i class="fa fa-cog fa-spin fa-3x fa-fw"></i></div>
        <div id="fb-root"></div>
        <a href="#nav-top" id="back_to_top" style="color:white;"><b>BACK TO TOP</b>
            &nbsp;&nbsp;<i class="fa
                fa-angle-double-up" aria-hidden="true"></i></a>

      <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL-PROJECT\multiple-listing\resources\views/welcome.blade.php ENDPATH**/ ?>