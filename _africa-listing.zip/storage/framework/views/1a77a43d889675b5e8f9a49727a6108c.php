<?php echo $__env->make('user.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">New Category Add Request to Listafrica Admin </h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form class="form-horizontal" id="request_form">
              <div class="card-body">
                <div class="form-group row">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Request Message</label>
                  <div class="col-sm-10">
                    <input type="text" name="request_message" class="form-control"  placeholder="Add Category Request Message text Here.." style="height:60px;" required>
                  </div>
                  <?php echo e(@csrf_field()); ?>


                 
                </div>
               
              
               
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                <center>
                    <button type="submit" id="btn" class="btn btn-info">Send Request </button>
                </center>
              </div>
              <!-- /.card-footer -->
            </form>
          </div>
      <!-- general form elements -->
      </div>
    </div>
</div>

<?php echo $__env->make('user.dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
  $('#password').addClass('active');
</script><?php /**PATH C:\xampp\htdocs\LARAVEL_PROJECTS\now-working\resources\views/user/dashboard/request_category.blade.php ENDPATH**/ ?>