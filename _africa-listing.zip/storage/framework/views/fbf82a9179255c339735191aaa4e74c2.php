<?php echo $__env->make('admin.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
  svg{
    display: none;
  }
  .leading-5{
    margin-top:16px !important;
  }
  .justify-between{
   margin-top:20px !important;
  }
  .dataTables_filter{
    display: flex;
    flex-direction: row-reverse;
  }
  .dataTables_length{
    position: absolute;
  }
  #myTable_previous{
    color: #007bff;
    background-color: transparent;
    border: 1px solid black;
    padding: 5px;
    margin-top: 5px;
    border-radius: 5px;
margin-left: 5px;
  }
  #myTable_next{
    color: #007bff;
    background-color: transparent;
    border: 1px solid black;
    padding: 5px;
    margin-top: 5px;
    border-radius: 5px;
margin-right: 5px;

  }
  #myTable_paginate{
    margin-top:10px;
    display: flex;
    flex-direction: row-reverse;
  }
  #myTable_filter label input{
    border-radius: 10px;
    margin-left:5px;
    outline: none;
  }
  </style>
<div class="content-wrapper">

<div class="card">
              <div class="card-header">
                <h2 class="card-title">User Question Table</h2>
              </div>
              <!-- /.card-header -->
              <div class="card-body" style="overflow: scroll">
                <table class="table table-bordered table-striped" id="myTable">
                  <thead>
                  <tr>
                    <th>Sl. No</th>
                    <th>User Name</th>
                    <th>Question</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                        $no = 1;
                    ?>
                 <?php if(count($users)>0): ?>
                 <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                     <td><?php echo e($no++); ?></td>
                     <td><?php echo e($val->user_name); ?></td>
                     <td><?php echo e($val->question); ?></td>
                   <?php if($val->status==0): ?>  <td><a href="<?php echo e(url('admin/dashboard/active')); ?>/<?php echo e($val->question_id); ?>"><button class="btn btn-success">Publish In Website</button> </a> <span class="text-danger">&nbsp; Currently Not Live </span></td>
                   <?php else: ?>  <td><a href="<?php echo e(url('admin/dashboard/deactive')); ?>/<?php echo e($val->question_id); ?>"><button class="btn btn-danger">Hide From Website</button></a> <span class="text-success">&nbsp; Currently Live </span></td>
                   <?php endif; ?>
                    
                 </tr>

                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                 <?php else: ?> 
                 <td colspan="6" style="color:red; text-align:center; ">Question Not Found</td>
                 <?php endif; ?>


                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
</div>
<?php echo $__env->make('admin.dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
<script>
  $('#question').addClass('active');
</script>
<script>
    let table = new DataTable('#myTable');
</script>
<?php /**PATH /home/u729855735/domains/kyptronixllp.co.in/public_html/africa-listing/resources/views/admin/dashboard/question.blade.php ENDPATH**/ ?>